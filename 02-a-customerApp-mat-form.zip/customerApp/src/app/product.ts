// quick assignment implement Product component 
// with Product model 
// refer 05-create-model-class.txt  
export class Product {
        id: number =0;
        name: string ="";
        country: string="";
        to: string="";
        from: string="";
}
